#!/usr/bin/env python3
"""
altgen.cc (zatic panel) - Roblox Account Generator Bot
PC version · Playwright · Telegram · Discord webhook
"""

import asyncio
import json
import re
import sys
from datetime import datetime
from pathlib import Path

try:
    from playwright.async_api import async_playwright
except ImportError:
    print("Playwright missing → pip install playwright && playwright install chromium")
    sys.exit(1)

try:
    import requests
except ImportError:
    print("requests missing → pip install requests")
    sys.exit(1)

CONFIG_FILE = Path("config.json")
EXAMPLE_CONFIG = Path("config.example.json")


def load_config():
    if not CONFIG_FILE.exists():
        print(f"[!] {CONFIG_FILE} not found.")
        print(f"    Copy {EXAMPLE_CONFIG} → config.json and fill in your details.")
        sys.exit(1)
    with open(CONFIG_FILE, encoding="utf-8") as f:
        return json.load(f)


def save_account(path: str, user: str, pwd: str) -> bool:
    line = f"{user}:{pwd}"
    p = Path(path)
    if p.exists() and line in p.read_text(encoding="utf-8"):
        return False
    with open(p, "a", encoding="utf-8") as f:
        f.write(line + "\n")
    return True


def send_telegram(token: str, chat_id: str, text: str):
    try:
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        r = requests.post(
            url,
            json={
                "chat_id": chat_id,
                "text": text,
                "parse_mode": "HTML",
                "disable_web_page_preview": True,
            },
            timeout=15,
        )
        if r.status_code != 200:
            print(f"    [TG] Error: {r.text[:120]}")
    except Exception as e:
        print(f"    [TG] Error: {e}")


def send_discord(webhook_url: str, content: str):
    try:
        r = requests.post(webhook_url, json={"content": content}, timeout=15)
        if r.status_code not in (200, 204):
            print(f"    [DC] Error: {r.status_code} {r.text[:120]}")
    except Exception as e:
        print(f"    [DC] Error: {e}")


def notify(cfg: dict, user: str, pwd: str):
    ts = datetime.now().strftime("%H:%M:%S")

    tg = cfg.get("telegram", {})
    if tg.get("enabled") and tg.get("bot_token") and tg.get("chat_id"):
        text = (
            f"<b>New account</b>\n"
            f"<code>{user}:{pwd}</code>\n"
            f"<i>{ts}</i>"
        )
        send_telegram(tg["bot_token"], str(tg["chat_id"]), text)

    dc = cfg.get("discord", {})
    if dc.get("enabled") and dc.get("webhook_url"):
        content = f"**New account** `{user}:{pwd}` · {ts}"
        send_discord(dc["webhook_url"], content)


async def run(cfg: dict):
    email = cfg["email"]
    password = cfg["password"]
    cooldown = int(cfg.get("cooldown", 45))
    accounts_file = cfg.get("accounts_file", "accounts.txt")
    headless = bool(cfg.get("headless", False))
    user_data_dir = cfg.get("user_data_dir", "browser_data")

    async with async_playwright() as p:
        browser = await p.chromium.launch_persistent_context(
            user_data_dir=user_data_dir,
            headless=headless,
            args=[
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox",
            ],
            viewport={"width": 1280, "height": 800},
            ignore_https_errors=True,
        )

        page = browser.pages[0] if browser.pages else await browser.new_page()

        print("[+] Opening https://altgen.cc/login ...")
        await page.goto("https://altgen.cc/login", wait_until="domcontentloaded")
        await page.wait_for_timeout(2000)

        # Cloudflare Turnstile
        try:
            if await page.locator("text=Verify you are human").count() > 0:
                print("\n[!] Cloudflare challenge detected.")
                print("    Check the box in the browser, then press Enter here.\n")
                input(">>> Press Enter after solving... ")
        except Exception:
            pass

        print("[+] Logging in...")
        try:
            await page.fill("#email, input[type='email']", email)
            await page.fill("#password, input[type='password']", password)
            await page.click("button:has-text('login'), button[type='submit']")
            print("[+] Login clicked")
        except Exception as e:
            print(f"[!] Login form error: {e}")
            input("Log in manually, then press Enter... ")

        await page.wait_for_timeout(5000)

        if "login" in page.url.lower():
            print("[!] Still on login page. Solve CF / check credentials, then Enter.")
            input()

        print(f"[+] Loop started · cooldown {cooldown}s")
        print(f"[+] Saving to {accounts_file}")
        tg_on = cfg.get("telegram", {}).get("enabled")
        dc_on = cfg.get("discord", {}).get("enabled")
        print(f"[+] Telegram: {'on' if tg_on else 'off'} · Discord: {'on' if dc_on else 'off'}")
        print("[+] Stop with Ctrl+C\n")

        selectors = [
            "button:has-text('Generate')",
            "button:has-text('generate')",
            "button:has-text('Gen')",
            "button:has-text('Free Gen')",
            "button:has-text('Claim')",
            "[class*='generate']",
            "[id*='generate']",
        ]

        while True:
            try:
                clicked = False
                for sel in selectors:
                    btn = page.locator(sel).first
                    if await btn.count() > 0 and await btn.is_visible():
                        await btn.click()
                        print(f"[{datetime.now().strftime('%H:%M:%S')}] Generate clicked")
                        clicked = True
                        break
                if not clicked:
                    print(f"[{datetime.now().strftime('%H:%M:%S')}] Button not found (cooldown?)")

                await page.wait_for_timeout(3500)

                body = await page.inner_text("body")
                matches = re.findall(
                    r"([a-zA-Z0-9_]{3,20})\s*[:\|\-–]\s*([a-zA-Z0-9!@#$%^&*._\-]{4,40})",
                    body,
                )

                for user, pwd in matches[-8:]:
                    if save_account(accounts_file, user, pwd):
                        print(f"    → {user}:{pwd}")
                        notify(cfg, user, pwd)

                print(f"    waiting {cooldown}s...\n")
                await page.wait_for_timeout(cooldown * 1000)

            except KeyboardInterrupt:
                print("\n[+] Stopped.")
                break
            except Exception as e:
                print(f"[!] Error: {e}")
                await page.wait_for_timeout(8000)

        await browser.close()


def main():
    cfg = load_config()
    email = cfg.get("email", "")
    password = cfg.get("password", "")
    if "your@" in email or password in ("yourpassword", "sifren", "password"):
        print("[!] Edit config.json with your real email and password.")
        sys.exit(1)
    asyncio.run(run(cfg))


if __name__ == "__main__":
    main()
