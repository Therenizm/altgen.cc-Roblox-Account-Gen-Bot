# altgen-bot

Automation bot for [altgen.cc](https://altgen.cc) (zatic panel) — Roblox account generator.

Clicks **Generate** on a cooldown, saves `username:password` to a file, and optionally sends each new account to **Telegram** and/or a **Discord webhook**.

## Features

- Playwright (Chromium) automation
- Persistent browser session (`browser_data/`)
- Cloudflare Turnstile: solve once manually, then autofill login
- Cooldown between generations
- Local `accounts.txt` log
- Telegram notifications
- Discord webhook notifications

## Requirements

- Python 3.9+
- Windows / Linux / macOS

## Install

```bash
git clone https://github.com/therenizm/altgen-bot.git
cd altgen-bot
pip install -r requirements.txt
playwright install chromium
```

## Config

```bash
cp config.example.json config.json
```

Edit `config.json`:

```json
{
  "email": "your@email.com",
  "password": "yourpassword",
  "cooldown": 45,
  "accounts_file": "accounts.txt",
  "headless": false,
  "user_data_dir": "browser_data",
  "telegram": {
    "enabled": false,
    "bot_token": "123456:ABC-DEF...",
    "chat_id": "YOUR_CHAT_ID"
  },
  "discord": {
    "enabled": false,
    "webhook_url": "https://discord.com/api/webhooks/..."
  }
}
```

| Key | Description |
|-----|-------------|
| `cooldown` | Seconds between Generate clicks (free tier often ~120s) |
| `headless` | Keep `false` so you can solve Cloudflare |
| `telegram.enabled` | Set `true` + token + chat_id to receive accounts |
| `discord.enabled` | Set `true` + webhook URL to post accounts |

### Telegram setup

1. Talk to [@BotFather](https://t.me/BotFather) → `/newbot` → copy the token  
2. Start a chat with your bot (`/start`)  
3. Get chat id: open `https://api.telegram.org/bot<TOKEN>/getUpdates`  
4. Put token and chat_id into `config.json`

### Discord webhook setup

1. Server → Channel settings → Integrations → Webhooks → New Webhook  
2. Copy the URL into `config.json`

## Run

```bash
python altgen_bot.py
```

1. Browser opens on the login page  
2. If Cloudflare “Verify you are human” appears → check it → press Enter in the terminal  
3. Bot logs in and starts the generate loop  
4. New accounts go to `accounts.txt` (+ Telegram / Discord if enabled)

Stop with `Ctrl+C`.

## Notes

- Do **not** commit `config.json` or `accounts.txt` (already in `.gitignore`)
- Session cookies live in `browser_data/` so you usually only solve CF once
- Selector list targets common Generate button labels; if the site UI changes, update the `selectors` list in `altgen_bot.py`

## Disclaimer

For personal automation / educational use. Respect the target site’s terms of service and rate limits. You are responsible for how you use this tool.
